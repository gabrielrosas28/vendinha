package br.com.santachiara.vendinha.domain

enum class SituacaoEstoque { SEM_LIMITE, NORMAL, ACABANDO, ESGOTADO }

/** Regras de estoque opcional por item (RF07, RF22). */
object RegrasEstoque {

    /** Com controle ligado, 3 ou menos já é "Acabando". */
    const val LIMITE_ACABANDO = 3

    fun situacao(controlaEstoque: Boolean, disponivel: Int?): SituacaoEstoque {
        if (!controlaEstoque) return SituacaoEstoque.SEM_LIMITE
        val d = disponivel ?: 0
        return when {
            d <= 0 -> SituacaoEstoque.ESGOTADO
            d <= LIMITE_ACABANDO -> SituacaoEstoque.ACABANDO
            else -> SituacaoEstoque.NORMAL
        }
    }

    /** Pode vender [quantidade] unidades? Itens sem limite nunca bloqueiam. */
    fun podeVender(controlaEstoque: Boolean, disponivel: Int?, quantidade: Int): Boolean =
        !controlaEstoque || quantidade <= (disponivel ?: 0)

    /** Pode somar mais 1 ao pedido, que já tem [noPedido] unidades deste item? */
    fun podeAdicionarUm(controlaEstoque: Boolean, disponivel: Int?, noPedido: Int): Boolean =
        podeVender(controlaEstoque, disponivel, noPedido + 1)

    /** Estoque depois da venda (só muda quando há controle). */
    fun aposVenda(controlaEstoque: Boolean, disponivel: Int?, quantidade: Int): Int? =
        if (controlaEstoque) (disponivel ?: 0) - quantidade else disponivel

    /** Estoque depois do estorno: devolve só quando há controle. */
    fun aposEstorno(controlaEstoque: Boolean, disponivel: Int?, quantidade: Int): Int? =
        if (controlaEstoque) (disponivel ?: 0) + quantidade else disponivel

    /**
     * Ao editar um item com controle, a criança informa "quantos tem agora".
     * A quantidade inicial acompanha a reposição para a barra continuar fazendo sentido.
     */
    fun inicialAposAjuste(inicialAtual: Int?, disponivelAtual: Int?, novoDisponivel: Int): Int {
        if (inicialAtual == null || disponivelAtual == null) return novoDisponivel
        return (inicialAtual + (novoDisponivel - disponivelAtual)).coerceAtLeast(novoDisponivel)
    }
}
