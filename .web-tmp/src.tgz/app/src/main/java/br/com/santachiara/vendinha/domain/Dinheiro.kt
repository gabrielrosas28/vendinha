package br.com.santachiara.vendinha.domain

/** Todo valor de dinheiro do app é um Long em centavos. Nunca Double/Float. */

enum class TipoDinheiro { CEDULA, MOEDA }

/** Cédulas e moedas brasileiras em circulação usadas na feira, da maior para a menor. */
enum class Denominacao(val centavos: Long, val tipo: TipoDinheiro) {
    R200(20_000, TipoDinheiro.CEDULA),
    R100(10_000, TipoDinheiro.CEDULA),
    R50(5_000, TipoDinheiro.CEDULA),
    R20(2_000, TipoDinheiro.CEDULA),
    R10(1_000, TipoDinheiro.CEDULA),
    R5(500, TipoDinheiro.CEDULA),
    R2(200, TipoDinheiro.CEDULA),
    M1(100, TipoDinheiro.MOEDA),
    M050(50, TipoDinheiro.MOEDA),
    M025(25, TipoDinheiro.MOEDA),
    M010(10, TipoDinheiro.MOEDA),
    M005(5, TipoDinheiro.MOEDA);

    companion object {
        val CEDULAS = entries.filter { it.tipo == TipoDinheiro.CEDULA }
        val MOEDAS = entries.filter { it.tipo == TipoDinheiro.MOEDA }
    }
}

/** Uma pilha de peças iguais: ex. 2 × R$ 5. */
data class Pecas(val denominacao: Denominacao, val quantidade: Int) {
    val totalCentavos: Long get() = denominacao.centavos * quantidade
}

/** Resultado da decomposição. [restoCentavos] só é > 0 se o valor não for múltiplo de 5 centavos. */
data class Decomposicao(val pecas: List<Pecas>, val restoCentavos: Long) {
    val totalPecas: Int get() = pecas.sumOf { it.quantidade }
}

object Dinheiro {

    /** Menor moeda em circulação. Preços precisam ser múltiplos dela para o troco fechar. */
    const val MENOR_MOEDA_CENTAVOS = 5L

    /** Limite de segurança para qualquer valor digitado (R$ 99.999,95). */
    const val MAXIMO_CENTAVOS = 9_999_995L

    /** Formata em pt-BR: 123456 → "R$ 1.234,56"; -500 → "-R$ 5,00". */
    fun formatar(centavos: Long): String {
        val sinal = if (centavos < 0) "-" else ""
        return "${sinal}R$ ${formatarSemSimbolo(centavos)}"
    }

    /** 123456 → "1.234,56" (sem sinal; usa o valor absoluto). */
    fun formatarSemSimbolo(centavos: Long): String {
        val abs = if (centavos == Long.MIN_VALUE) Long.MAX_VALUE else kotlin.math.abs(centavos)
        val reais = abs / 100
        val cent = abs % 100
        val reaisTxt = reais.toString().reversed().chunked(3).joinToString(".").reversed()
        return "$reaisTxt,${cent.toString().padStart(2, '0')}"
    }

    /**
     * Lê o que a pessoa digitou ("2", "2,5", "2,50", "1.234,56", "R$ 3,00", "2.50") e devolve centavos.
     * Devolve null se não for um valor válido.
     */
    fun lerReais(texto: String): Long? {
        var t = texto.trim().replace("R$", "").replace(" ", "").replace(" ", "")
        if (t.isEmpty()) return null
        // Se só houver ponto e ele tiver 1 ou 2 casas depois, é separador decimal ("2.50").
        if (!t.contains(',') && t.count { it == '.' } == 1 && t.substringAfter('.').length in 1..2) {
            t = t.replace('.', ',')
        }
        t = t.replace(".", "")
        val partes = t.split(',')
        if (partes.size > 2) return null
        val inteiro = partes[0].ifEmpty { "0" }
        val decimal = partes.getOrNull(1) ?: ""
        if (!inteiro.all { it.isDigit() } || !decimal.all { it.isDigit() }) return null
        if (decimal.length > 2 || inteiro.length > 7) return null
        val centavos = inteiro.toLong() * 100 + decimal.padEnd(2, '0').ifEmpty { "00" }.toLong()
        return if (centavos > MAXIMO_CENTAVOS) null else centavos
    }

    /**
     * Decompõe o troco pelo algoritmo guloso nas cédulas e moedas brasileiras.
     * O sistema brasileiro é canônico, então o guloso dá o menor número de peças.
     * Ex.: 800 → 1×R$5 + 1×R$2 + 1×R$1.
     */
    fun decomporTroco(centavos: Long): Decomposicao {
        require(centavos >= 0) { "Troco não pode ser negativo" }
        var resto = centavos
        val pecas = mutableListOf<Pecas>()
        for (d in Denominacao.entries) {
            val qtd = resto / d.centavos
            if (qtd > 0) {
                pecas += Pecas(d, qtd.toInt())
                resto -= qtd * d.centavos
            }
        }
        return Decomposicao(pecas, resto)
    }

    /** Soma de uma contagem de peças (ex.: o que a criança tocou na tela de pagamento). */
    fun somar(contagem: Map<Denominacao, Int>): Long =
        contagem.entries.sumOf { (d, q) -> d.centavos * q }

    /** Agrupa uma contagem em lista ordenada da maior para a menor peça. */
    fun emPecas(contagem: Map<Denominacao, Int>): List<Pecas> =
        Denominacao.entries.mapNotNull { d -> contagem[d]?.takeIf { it > 0 }?.let { Pecas(d, it) } }

    fun ehMultiploDaMenorMoeda(centavos: Long): Boolean = centavos % MENOR_MOEDA_CENTAVOS == 0L
}
