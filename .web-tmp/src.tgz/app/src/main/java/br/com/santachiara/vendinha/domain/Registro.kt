package br.com.santachiara.vendinha.domain

/** O que o registro de vendas guarda de cada compra, para as contas. */
data class ValorRegistro(
    val totalCentavos: Long,
    val recebidoCentavos: Long,
    val trocoCentavos: Long,
    val estornada: Boolean,
)

/**
 * Totais do registro (sem as vendas estornadas, que foram desfeitas).
 * Sempre vale: recebido − troco = vendido.
 */
data class TotaisRegistro(
    val numeroVendas: Int,
    val numeroEstornadas: Int,
    val vendidoCentavos: Long,
    val recebidoCentavos: Long,
    val trocoCentavos: Long,
)

object Registro {
    fun totais(vendas: List<ValorRegistro>): TotaisRegistro {
        val validas = vendas.filterNot { it.estornada }
        return TotaisRegistro(
            numeroVendas = validas.size,
            numeroEstornadas = vendas.size - validas.size,
            vendidoCentavos = validas.sumOf { it.totalCentavos },
            recebidoCentavos = validas.sumOf { it.recebidoCentavos },
            trocoCentavos = validas.sumOf { it.trocoCentavos },
        )
    }

    /** Nome de turma aceito: 1 a 20 caracteres depois de tirar espaços. */
    fun nomeTurmaValido(nome: String): Boolean = nome.trim().length in 1..20

    /** Nome do produto de um grupo: 1 a 40 caracteres. */
    fun nomeGrupoValido(nome: String): Boolean = nome.trim().length in 1..40
}
