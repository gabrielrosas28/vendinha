package br.com.santachiara.vendinha.domain

/** Valor mínimo de uma venda para as contas do caixa. */
data class ValorVenda(val totalCentavos: Long, val estornada: Boolean)

enum class ResultadoConferencia { BATEU, SOBROU, FALTOU }

/** Regras puras de dinheiro do caixa (seção 4 do documento). */
object ContaCaixa {

    /** totalGanho = soma das vendas − vendas estornadas. */
    fun totalGanho(vendas: List<ValorVenda>): Long =
        vendas.sumOf { it.totalCentavos } - vendas.filter { it.estornada }.sumOf { it.totalCentavos }

    fun numeroVendasValidas(vendas: List<ValorVenda>): Int = vendas.count { !it.estornada }

    /** dinheiroEsperado = trocoInicial + totalGanho (troco inicial é 0 se o grupo pulou). */
    fun dinheiroEsperado(trocoInicialCentavos: Long, totalGanhoCentavos: Long): Long =
        trocoInicialCentavos + totalGanhoCentavos

    /** diferenca = contado − esperado (positivo: sobrou; negativo: faltou; zero: bateu). */
    fun diferenca(contadoCentavos: Long, esperadoCentavos: Long): Long =
        contadoCentavos - esperadoCentavos

    fun resultado(diferencaCentavos: Long): ResultadoConferencia = when {
        diferencaCentavos > 0 -> ResultadoConferencia.SOBROU
        diferencaCentavos < 0 -> ResultadoConferencia.FALTOU
        else -> ResultadoConferencia.BATEU
    }

    /** Troco da venda. Negativo significa que ainda falta dinheiro. */
    fun troco(totalCentavos: Long, recebidoCentavos: Long): Long = recebidoCentavos - totalCentavos

    /** A venda só confirma se houver algo no pedido e recebido >= total. */
    fun podeConfirmar(totalCentavos: Long, recebidoCentavos: Long): Boolean =
        totalCentavos > 0 && recebidoCentavos >= totalCentavos
}
